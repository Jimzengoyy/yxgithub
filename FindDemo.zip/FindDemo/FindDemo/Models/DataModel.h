//
//  DataModel.h
//  SecondApp
//
//  Created by 杨晨曦 on 15/12/23.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONModel.h"
#import "DataModels.h"
@class Status,Data,Resultarray;
@interface Model : JSONModel


@property (nonatomic, strong) Status *status;

@property (nonatomic, strong) DataModels *data;



//@end
//@interface Statuss : NSObject
//
//@property (nonatomic, copy) NSString *msg;
//
//@property (nonatomic, copy) NSString *code;
//
//@end
//
//@interface Data : NSObject
//
//@property (nonatomic, assign) NSInteger TotalNumber;
//
//@property (nonatomic, copy) NSString *Column;
//
//@property (nonatomic, strong) NSArray<Resultarray *> *ResultArray;
//
//@property (nonatomic, assign) NSInteger ReturnNumber;
//
//@end
//
//@interface Resultarray : NSObject
//
//@property (nonatomic, copy) NSString *Key;
//
//@property (nonatomic, strong) NSArray *SetArray;
//
//@property (nonatomic, assign) NSInteger SetObjNum;
//
//@property (nonatomic, assign) NSInteger IsSet;
//
//@property (nonatomic, assign) NSInteger Height;
//
//@property (nonatomic, copy) NSString *Pictype;
//
//@property (nonatomic, assign) NSInteger Width;
//
//@property (nonatomic, copy) NSString *Desc;
//
//@property (nonatomic, copy) NSString *FromUrl;
//
//@property (nonatomic, copy) NSString *ObjUrl;
//
//@property (nonatomic, assign) NSInteger Pagenum;
//
//@property (nonatomic, copy) NSString *Di;
//
//@property (nonatomic, copy) NSString *SetId;
//
@end
//
