//
//  TicketModel.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/28.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <Foundation/Foundation.h>

@class TicketData,Trainlist,Seatinfos;
@interface TicketModel : JSONModel

@property (nonatomic, assign) BOOL ret;

@property (nonatomic, strong) TicketData * data;

@end
@interface TicketData : JSONModel

@property (nonatomic, strong) NSArray * trainList;

@end

@interface Trainlist : JSONModel

@property (nonatomic, copy) NSString *from;

@property (nonatomic, copy) NSString *endTime;

@property (nonatomic, copy) NSString *trainType;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, strong) NSArray<Seatinfos *> *seatInfos;

@property (nonatomic, copy) NSString *startTime;

@property (nonatomic, copy) NSString *to;

@property (nonatomic, copy) NSString *trainNo;

@end

@interface Seatinfos : JSONModel

@property (nonatomic, copy) NSString *seatPrice;

@property (nonatomic, assign) NSInteger remainNum;

@property (nonatomic, copy) NSString *seat;

@end

