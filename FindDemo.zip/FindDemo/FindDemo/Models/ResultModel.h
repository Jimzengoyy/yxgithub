//
//  ResultModel.h
//  SecondApp
//
//  Created by 杨晨曦 on 15/12/23.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONModel.h"
@interface ResultModel : JSONModel
@property (nonatomic, copy) NSString *Key;

@property (nonatomic, strong) NSArray *SetArray;

@property (nonatomic, assign) NSInteger SetObjNum;

@property (nonatomic, assign) NSInteger IsSet;

@property (nonatomic, assign) NSInteger Height;

@property (nonatomic, copy) NSString *Pictype;

@property (nonatomic, assign) NSInteger Width;

@property (nonatomic, copy) NSString *Desc;

@property (nonatomic, copy) NSString *FromUrl;

@property (nonatomic, copy) NSString *ObjUrl;

@property (nonatomic, assign) NSInteger Pagenum;

@property (nonatomic, copy) NSString *Di;

@property (nonatomic, copy) NSString *SetId;
@end
