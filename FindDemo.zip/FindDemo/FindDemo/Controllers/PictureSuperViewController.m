//
//  PictureSuperViewController.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/28.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "PictureSuperViewController.h"




@interface PictureSuperViewController ()<UIScrollViewDelegate>

{
    UIImageView * _topImageView; // 顶部的图片
    UIImageView * _bottomImageView; // 底部的图片
    UILabel * _titleLabel;
    UIButton * _doneButton;
    UIButton * _saveButton;
}



@end

@implementation PictureSuperViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    self.scrollView.effect = JT3DScrollViewEffectCards;
    [self createUI];
    [self addObserver:self forKeyPath:@"selectedIndex" options:NSKeyValueObservingOptionNew context:nil];
    NSLog(@"%ld",self.imageArray.count);
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;


}

- (void)dealloc
{
    // 移除观察者
    [self removeObserver:self forKeyPath:@"selectedIndex"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)createCardWithColor
{
    CGFloat width = CGRectGetWidth(self.scrollView.frame)-225;
   
    CGFloat height = CGRectGetHeight(self.scrollView.frame);
    
    CGFloat x = self.scrollView.subviews.count * width;
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(x, 0, width, height)];
    view.backgroundColor = [UIColor colorWithRed:33/255. green:158/255. blue:238/255. alpha:1.];
    
    view.layer.cornerRadius = 8.;
    
    [self.scrollView addSubview:view];
    self.scrollView.contentSize = CGSizeMake(x + width, height);
}





-(void)createUI{
    _topImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 20, ScreenSize.width, 44)];
    [self.view addSubview:_topImageView];
    _topImageView.image = [UIImage imageNamed:@"tabbar_bg"];
    _topImageView.userInteractionEnabled = YES;
    
    _bottomImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, ScreenSize.height - 44, ScreenSize.width, 44)];
    [self.view addSubview:_bottomImageView];
    _bottomImageView.image = [UIImage imageNamed:@"tabbar_bg"];
    _bottomImageView.userInteractionEnabled = YES;
    
    
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetWidth(_topImageView.frame)/2 - 100, 0, 200, CGRectGetHeight(_topImageView.frame))];
    [_topImageView addSubview:_titleLabel];
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:20];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    
    _doneButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_topImageView addSubview:_doneButton];
    _doneButton.frame = CGRectMake(CGRectGetWidth(_topImageView.frame) - 60, 7, 50, 30);
    [_doneButton setTitle:@"完成" forState:UIControlStateNormal];
    _doneButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [_doneButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_doneButton addTarget:self action:@selector(doneButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    _saveButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_bottomImageView addSubview:_saveButton];
    _saveButton.frame = _doneButton.frame;
    [_saveButton setTitle:@"保存" forState:UIControlStateNormal];
    _saveButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [_saveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_saveButton addTarget:self action:@selector(saveButtonClicked:) forControlEvents:UIControlEventTouchUpInside];

    
    
    [self.view addSubview:self.scrollView];
    self.scrollView.backgroundColor = [UIColor blackColor];
    self.scrollView.delegate = self;
    self.scrollView.contentOffset = CGPointMake(self.selectedIndex*(self.scrollView.bounds.size.width-225), 0);
    self.scrollView.contentSize = CGSizeMake(self.imageArray.count * self.scrollView.bounds.size.width-225, self.scrollView.bounds.size.height-69);
    self.scrollView.bounces = NO;
    self.scrollView.pagingEnabled = YES;
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onPicTap:)];
    [self.scrollView addGestureRecognizer:tapGesture];
    CGFloat width = CGRectGetWidth(self.scrollView.frame)-225;
    
    CGFloat height = CGRectGetHeight(self.scrollView.frame);
    
    
    
    for (int i = 0 ; i<self.imageArray.count; i++) {
        CGFloat x = i * width;
        UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(x, 0, width, height)];
        [self.scrollView addSubview:imageView];
        [imageView sd_setImageWithURL:[NSURL URLWithString:self.imageArray[i]] placeholderImage:[UIImage imageNamed:@"topic_TopicImage_Default"]];

    }
}
- (void)onPicTap:(UITapGestureRecognizer *) sender
{
    // 判断视图是否隐藏
    if ([_topImageView isHidden]) {
        _topImageView.hidden = NO;
        _bottomImageView.hidden =NO;
        [UIApplication sharedApplication].statusBarHidden = NO;
    }
    else {
        _topImageView.hidden = YES;
        _bottomImageView.hidden = YES;
        [UIApplication sharedApplication].statusBarHidden = YES;
    }
}
- (void)doneButtonClicked:(UIButton *) sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveButtonClicked:(UIButton *) sender
{
    [KVNProgress showWithStatus:@"保存图片到相册中..."];
    
    // 获取当前UIScrollView显示的UIImageView
    UIImageView * imageView = self.scrollView.subviews[self.selectedIndex];
    // 保存UIImageView上图片到相册中
    // 参数2和参数3：target-action 保存图片完成后的回调
    // 参数4：上下文
    UIImageWriteToSavedPhotosAlbum(imageView.image, self, @selector(saveImage:didFinishSavingWithError:contextInfo:), nil);
}

- (void)saveImage:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error) {
        NSLog(@"保存失败");
        [KVNProgress showErrorWithStatus:@"保存图片失败，请重新保存"];
    }
    else {
        NSLog(@"保存成功");
        [KVNProgress showSuccessWithStatus:@"保存成功"];
    }
    
}
#pragma mark - UIScrollViewDelegate

// 减速结束回调
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    self.selectedIndex = scrollView.contentOffset.x / scrollView.frame.size.width;
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    _titleLabel.text = [NSString stringWithFormat:@"%ld of %ld", self.selectedIndex+1, self.imageArray.count];
}


@end
