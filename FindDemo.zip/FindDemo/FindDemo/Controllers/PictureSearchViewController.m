//
//  PictureSearchViewController.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/26.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "PictureSearchViewController.h"
#import "PictureViewController.h"
@interface PictureSearchViewController ()
@property (weak, nonatomic) IBOutlet UITextField *pictureTitleTF;
- (IBAction)searchClicked:(UIButton *)sender;

@end

@implementation PictureSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIImageView * backgroundImageView = [[UIImageView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:backgroundImageView];
    [self.view sendSubviewToBack:backgroundImageView];
    backgroundImageView.image = [UIImage imageNamed:@"17aafe58e7c630245b759a10134dfa58.jpeg"];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)searchClicked:(UIButton *)sender {
    
    
    PictureViewController * pictureVC = [[PictureViewController alloc]init];
    pictureVC.text = self.pictureTitleTF.text;
    [self.navigationController pushViewController:pictureVC animated:YES];
    
}
@end
