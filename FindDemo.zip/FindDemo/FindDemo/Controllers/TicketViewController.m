//
//  TicketViewController.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/28.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "TicketViewController.h"
#import "TicketSearchViewController.h"
@interface TicketViewController ()
@property (weak, nonatomic) IBOutlet UITextField *leaveCityTF;
@property (weak, nonatomic) IBOutlet UITextField *arriveCityTF;
@property (weak, nonatomic) IBOutlet UITextField *yearTF;
@property (weak, nonatomic) IBOutlet UITextField *monthTF;
@property (weak, nonatomic) IBOutlet UITextField *dayTF;

- (IBAction)ticketSearchClicked:(UIButton *)sender;

@end

@implementation TicketViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIImageView * backgroundImageView = [[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:backgroundImageView];
    [self.view sendSubviewToBack:backgroundImageView];
    backgroundImageView.image = [UIImage imageNamed:@"34YFI2FQK0XU.jpg"];
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)ticketSearchClicked:(UIButton *)sender {
    TicketSearchViewController * ticketSearchVC = [[TicketSearchViewController alloc]init];
    ticketSearchVC.leaveCity = self.leaveCityTF.text;
    ticketSearchVC.arriveCity = self.arriveCityTF.text;
    ticketSearchVC.year = self.yearTF.text;
    ticketSearchVC.month = self.monthTF.text;
    ticketSearchVC.day = self.dayTF.text;
    [self.navigationController pushViewController:ticketSearchVC animated:YES];
    
    
}
@end
