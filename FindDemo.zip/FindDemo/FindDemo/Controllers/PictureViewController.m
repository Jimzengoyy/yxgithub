//
//  PictureViewController.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/26.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "PictureViewController.h"
#import "PictureCell.h"
#import "DataModel.h"
#import "DataModels.h"
#import "ResultModel.h"
#import "PictureSuperViewController.h"
@interface PictureViewController ()<UICollectionViewDataSource, UICollectionViewDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic,strong)NSMutableArray * namesArray;
@property (nonatomic,strong)NSMutableArray * pictureArray;
@end

@implementation PictureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.pictureArray = [NSMutableArray array];
    self.namesArray = [NSMutableArray array];
    [self customNavigationItem];
    [self.collectionView registerNib:[UINib nibWithNibName:@"PictureCell" bundle:nil] forCellWithReuseIdentifier:@"PictureCell"];
    UICollectionViewFlowLayout * flowLayout = (UICollectionViewFlowLayout *)self.collectionView.collectionViewLayout;
    flowLayout.itemSize = CGSizeMake(170, 200);
    //行间距
    flowLayout.minimumLineSpacing =10;
    //单元格间距
    flowLayout.minimumInteritemSpacing = 0;
    //设置内间距
    flowLayout.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);
    
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self requestData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)customNavigationItem{
    [self addNavigationItemTitle:self.text];
    [self addBarButtonItemWithTarget:self  action:@selector(back:) name:@"返回" isLeft:YES];
    UIButton * leftButton = self.navigationItem.leftBarButtonItem.customView;
    [leftButton setBackgroundImage:[UIImage imageNamed:@"buttonbar_back"] forState:UIControlStateNormal];



}

- (void)back:(UIButton *) sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)request: (NSString*)httpUrl withHttpArg: (NSString*)HttpArg  {
    NSString *urlStr = [[NSString alloc]initWithFormat: @"%@?%@", httpUrl, HttpArg];
    NSURL *url = [NSURL URLWithString: urlStr];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL: url cachePolicy: NSURLRequestUseProtocolCachePolicy timeoutInterval: 10];
    [request setHTTPMethod: @"GET"];
    [request addValue: @"f32d36430908634a557ea641216af86c" forHTTPHeaderField: @"apikey"];
    [NSURLConnection sendAsynchronousRequest: request
                                       queue: [NSOperationQueue mainQueue]
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error){
                               if (error) {
                                   NSLog(@"Httperror: %@%ld", error.localizedDescription, error.code);
                               } else {
                                   //                                   NSError * err = [[NSError alloc]init];
                                   
                                   NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                   Model * model = [[Model alloc]initWithString:responseString usingEncoding:NSUTF8StringEncoding error:nil];
                                   for (NSDictionary * dict in model.data.ResultArray) {
                                       [self.pictureArray addObject:dict[@"ObjUrl"]];
                                       NSString * str = [NSString stringWithFormat:@"%@ * %@",dict[@"Width"],dict[@"Height"]];
                                       [self.namesArray addObject:str];
                                   }
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       [self.collectionView reloadData];
                                       
                                   });
                                   
                               }
                           }];
    
    
}

-(void)requestData{
    NSString * str = [self.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *httpUrl = @"http://apis.baidu.com/image_search/search/search";
    NSString *httpArg = [NSString stringWithFormat:@"word=%@&pn=0&rn=60&ie=utf-8",str];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self request:httpUrl withHttpArg:httpArg];
    });






}
#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.pictureArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PictureCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PictureCell" forIndexPath:indexPath];
    NSString * str = self.pictureArray[indexPath.row];
    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:str] placeholderImage:[UIImage imageNamed:@"category_FoodDrink"]];
    cell.nameLabel.text = self.namesArray[indexPath.row];
        return cell;
    
    
    
    
}

#pragma mark - UICollectionViewDelegate

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{

    PictureSuperViewController * pictureSuperVC = [[PictureSuperViewController alloc]init];
    pictureSuperVC.imageArray = self.pictureArray;
//    pictureSuperVC.hidesBottomBarWhenPushed = YES;
    pictureSuperVC.selectedIndex = indexPath.row;
    [self presentViewController:pictureSuperVC animated:YES completion:nil];
    
    
}



@end
