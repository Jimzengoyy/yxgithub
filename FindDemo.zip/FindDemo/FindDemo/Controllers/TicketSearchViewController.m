//
//  TicketSearchViewController.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/28.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "TicketSearchViewController.h"
#import "TicketModel.h"
#import "TicketCell.h"
@interface TicketSearchViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)NSMutableArray * addressArray;
@property (nonatomic,strong)NSMutableArray * timeArray;
@property (nonatomic,strong)NSMutableArray * trainNoArray;
@property (nonatomic,strong)NSMutableArray * trainTypeArray;
@property (nonatomic,strong)UITableView * tableView;
@end

@implementation TicketSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.addressArray = [NSMutableArray array];
    self.timeArray = [NSMutableArray array];
    self.trainNoArray = [NSMutableArray array];
    self.trainTypeArray = [NSMutableArray array];
    self.tableView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.tableView registerNib:[UINib nibWithNibName:@"TicketCell" bundle:nil]forCellReuseIdentifier:@"TicketCell"];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 100;
    [self requestData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)request: (NSString*)httpUrl withHttpArg: (NSString*)HttpArg  {
    NSString *urlStr = [[NSString alloc]initWithFormat: @"%@?%@", httpUrl, HttpArg];
    NSURL *url = [NSURL URLWithString: urlStr];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL: url cachePolicy: NSURLRequestUseProtocolCachePolicy timeoutInterval: 10];
    [request setHTTPMethod: @"GET"];
    [request addValue: @"f32d36430908634a557ea641216af86c" forHTTPHeaderField: @"apikey"];
    [NSURLConnection sendAsynchronousRequest: request
                                       queue: [NSOperationQueue mainQueue]
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error){
                               if (error) {
                                   NSLog(@"Httperror: %@%ld", error.localizedDescription, error.code);
                               } else {
                                   NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                                 TicketModel * ticketModel = [[TicketModel alloc]initWithString:responseString usingEncoding:NSUTF8StringEncoding error:nil];
                                   for (NSDictionary * dict in ticketModel.data.trainList) {
//                                       [self.pictureArray addObject:dict[@"ObjUrl"]];
                                       NSString * address = [NSString stringWithFormat:@"%@     至     %@",dict[@"from"],dict[@"to"]];
                                       [self.addressArray addObject:address];
                                       NSString * time = [NSString stringWithFormat:@"%@  --- %@  ---  %@",dict[@"startTime"],dict[@"duration"],dict[@"endTime"]];
                                       [self.timeArray addObject:time];
                                       [self.trainNoArray addObject:dict[@"trainNo"]];
                                       [self.trainTypeArray addObject:dict[@"trainType"]];
                                                                          }
                                   NSLog(@"%ld",self.trainNoArray.count);
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       [self.tableView reloadData];

                                       
                                   });

                               }
                           }];
}
-(void)requestData{
    NSString * leave = [self.leaveCity stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString * arrive = [self.arriveCity stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString * ye = [self.year stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString * mo = [self.month stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString * da = [self.day stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

NSString *httpUrl = @"http://apis.baidu.com/qunar/qunar_train_service/s2ssearch";
    NSString *httpArg =[NSString stringWithFormat:@"version=1.0&from=%@&to=%@&date=%@-%@-%@",leave,arrive,ye,mo,da];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self request: httpUrl withHttpArg: httpArg];
    });
}

#pragma mark - UITableViewDelegate/UITableViewDataSourse

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.addressArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    TicketCell * cell = [tableView dequeueReusableCellWithIdentifier:@"TicketCell" forIndexPath:indexPath];
    cell.addressLabel.text = self.addressArray[indexPath.row];
    cell.timeLabel.text = self.timeArray[indexPath.row];
    cell.trainNoLabel.text = self.trainNoArray[indexPath.row];
    cell.trainTypeLabel.text = self.trainTypeArray[indexPath.row];

    return cell;

}

@end
