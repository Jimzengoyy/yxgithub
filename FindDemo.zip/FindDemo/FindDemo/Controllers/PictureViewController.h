//
//  PictureViewController.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/26.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface PictureViewController : BaseViewController
@property(nonatomic,copy)NSString * text;
@end
