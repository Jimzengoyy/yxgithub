//
//  TabBarViewController.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/26.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "TabBarViewController.h"
#import "PictureSearchViewController.h"
#import "TicketViewController.h"
@interface TabBarViewController ()

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self customTabBar];
    [self createViewControllers];
    [self customNavigationBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)createViewControllers{
    NSMutableArray * viewVontrollers = [NSMutableArray array];
    
    TicketViewController * ticketVC = [[TicketViewController alloc]init];
    ticketVC.title = @"车票搜索";
    UINavigationController * ticketNavi = [[UINavigationController alloc]initWithRootViewController:ticketVC];
    [ticketVC addNavigationItemTitle:@"车票搜索"];
    
    UIImage * ticketNormalImage = [[UIImage imageNamed:@"tabbar_account"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIImage * ticketSelectedImage = [[UIImage imageNamed:@"tabbar_account_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UITabBarItem * ticketTabBarItem = [[UITabBarItem alloc]initWithTitle:@"车票搜索" image:ticketNormalImage selectedImage:ticketSelectedImage];
    
    ticketNavi.tabBarItem = ticketTabBarItem;
    
    PictureSearchViewController * pictureVC = [[PictureSearchViewController alloc]init];
    pictureVC.title = @"美图搜索";
    UINavigationController * pictureNavi = [[UINavigationController alloc]initWithRootViewController:pictureVC];
    [pictureVC addNavigationItemTitle:@"美图搜索"];
    
    UIImage * pictureNormalImage = [[UIImage imageNamed:@"tabbar_subject"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIImage * pictureSelectedImage = [[UIImage imageNamed:@"tabbar_subject_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UITabBarItem * pictureTabBarItem = [[UITabBarItem alloc]initWithTitle:@"美图搜索" image:pictureNormalImage selectedImage:pictureSelectedImage];
    
    pictureNavi.tabBarItem = pictureTabBarItem;
    
    [viewVontrollers addObject:pictureNavi];
    [viewVontrollers addObject:ticketNavi];
    self.viewControllers = viewVontrollers;
    

}


-(void)customTabBar{
    UITabBar * tabBar = self.tabBar;
    [tabBar setBackgroundImage:[UIImage imageNamed:@"tabbar_bg"]];


}

-(void)customNavigationBar{

    NSArray * viewControllers = self.viewControllers;
    for (UINavigationController * navi in viewControllers) {
        UINavigationBar * navigationBar = navi.navigationBar;
        [navigationBar setBackgroundImage:[UIImage imageNamed:@"navigationbar"] forBarMetrics:UIBarMetricsDefault];
    }

}





@end
