//
//  BaseViewController.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/26.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

// 设置导航项上的title
- (void)addNavigationItemTitle:(NSString *) title;

// 设置导航项上的UIBarButtonItem
- (void)addBarButtonItemWithTarget:(id)target action:(SEL)selector name:(NSString *) name isLeft:(BOOL) isLeft;

@end
