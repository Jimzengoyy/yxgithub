//
//  TicketSearchViewController.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/28.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface TicketSearchViewController : BaseViewController
@property (nonatomic,copy)NSString * leaveCity;
@property (nonatomic,copy)NSString * arriveCity;
@property (nonatomic,copy)NSString * year;
@property (nonatomic,copy)NSString * month;
@property (nonatomic,copy)NSString * day;

@end
