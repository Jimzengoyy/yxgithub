//
//  PictureSuperViewController.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/28.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface PictureSuperViewController : UIViewController
@property (weak, nonatomic) IBOutlet JT3DScrollView *scrollView;
@property (nonatomic,strong) NSMutableArray * imageArray;
@property (nonatomic,assign)NSInteger selectedIndex;
@end
