//
//  TicketCell.m
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/29.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import "TicketCell.h"

@implementation TicketCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
