//
//  TicketCell.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/29.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TicketCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *trainNoLabel;

@property (weak, nonatomic) IBOutlet UILabel *trainTypeLabel;
@end
