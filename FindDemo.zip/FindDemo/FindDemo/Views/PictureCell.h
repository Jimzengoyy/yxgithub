//
//  PictureCell.h
//  FindDemo
//
//  Created by 杨晨曦 on 15/12/26.
//  Copyright © 2015年 杨晨曦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PictureCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end
