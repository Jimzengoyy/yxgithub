//
//  SubjectAppView.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/16.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppModel.h"

@interface SubjectAppView : UIView

// 绑定模型
@property (nonatomic, strong) AppModel * model;

@end
