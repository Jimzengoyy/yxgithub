//
//  SubjectCell.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/16.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubjectModel.h"

@interface SubjectCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *subjectTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *subjectImageView;
@property (weak, nonatomic) IBOutlet UIView *appListView;
@property (weak, nonatomic) IBOutlet UIImageView *descImageView;
@property (weak, nonatomic) IBOutlet UITextView *descTextView;

// 单元格对应的模型
@property (nonatomic, strong) SubjectModel * model;

@end
