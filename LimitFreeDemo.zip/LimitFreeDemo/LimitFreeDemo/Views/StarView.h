//
//  StarView.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/15.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StarView : UIView

// 当前StarView的取值
@property (nonatomic, assign) CGFloat startValue;

@end
