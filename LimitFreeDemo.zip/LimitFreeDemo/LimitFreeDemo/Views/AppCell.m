//
//  AppCell.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/15.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "AppCell.h"
#import "UIImageView+WebCache.h"

@implementation AppCell

// 从Nib文件中恢复
- (void)awakeFromNib {
    // Initialization code
    // 设置图片的圆角
    self.appImageView.layer.cornerRadius = 40;
    self.appImageView.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

// 重写model属性的Setter方法
- (void)setModel:(AppModel *)model
{
    _model = model;
    // 设置UI
    [self.appImageView sd_setImageWithURL:[NSURL URLWithString:_model.iconUrl] placeholderImage:[UIImage imageNamed:@"appproduct_appdefault"]];
    self.appNameLabel.text = _model.name;
    self.expireDateLabel.text = _model.expireDatetime;
    
    // 创建多种样式的文本
    NSAttributedString * lastPriceAttr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"￥%@", _model.lastPrice] attributes:@{NSStrikethroughStyleAttributeName : @2, NSStrikethroughColorAttributeName : [UIColor purpleColor]}];
    
    self.lastPriceLabel.attributedText = lastPriceAttr;
    
    // 设置星标
    self.starCurrentView.startValue = [_model.starCurrent floatValue];
    
    self.categoryNameLabel.text = _model.categoryName;
    
    NSString * appTimesStr = [NSString stringWithFormat:@"分享：%@次 收藏：%@次 下载：%@次", _model.shares, _model.favorites, _model.downloads];
    self.appTimesLabel.text = appTimesStr;
}

@end
