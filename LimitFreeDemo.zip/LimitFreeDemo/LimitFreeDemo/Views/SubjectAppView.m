//
//  SubjectAppView.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/16.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "SubjectAppView.h"
#import "StarView.h"
#import "UIImageView+WebCache.h"

@implementation SubjectAppView
{
    UIImageView * _imageView;
    UILabel * _appNameLabel;
    UIImageView * _commentImageView;
    UILabel * _commentLabel;
    UIImageView * _downloadImageView;
    UILabel * _downloadLabel;
    StarView *_starView;
}

// 重写初始化方法

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self createUI];
    }
    return self;
}

// 创建视图
- (void)createUI
{
    self.layer.borderWidth = 1;
    self.layer.borderColor = [UIColor whiteColor].CGColor;
    _imageView = [[UIImageView alloc] init];
    [self addSubview:_imageView];
    
    _appNameLabel = [[UILabel alloc] init];
    [self addSubview:_appNameLabel];
    _appNameLabel.font = [UIFont systemFontOfSize:14];
    
    _commentImageView = [[UIImageView alloc] init];
    [self addSubview:_commentImageView];
    _commentImageView.image = [UIImage imageNamed:@"topic_Comment"];
    
    _commentLabel = [[UILabel alloc] init];
    [self addSubview:_commentLabel];
    _commentLabel.font = [UIFont systemFontOfSize:13];
    
    _downloadImageView = [[UIImageView alloc] init];
    [self addSubview:_downloadImageView];
    _downloadImageView.image = [UIImage imageNamed:@"topic_Download"];
    
    _downloadLabel = [[UILabel alloc] init];
    [self addSubview:_downloadLabel];
    _downloadLabel.font = [UIFont systemFontOfSize:13];
    
    _starView = [[StarView alloc] init];
    [self addSubview:_starView];
    
    // 布局
    _imageView.translatesAutoresizingMaskIntoConstraints = NO;
    [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(3);
        make.top.equalTo(self.mas_top).offset(3);
        make.bottom.equalTo(self.mas_bottom).offset(-3);
        make.width.equalTo(_imageView.mas_height);
    }];
    
    [_appNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(_imageView.mas_right).offset(8);
    }];
    
    [_commentImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_appNameLabel.mas_left);
        make.centerY.equalTo(_imageView.mas_centerY);
        make.width.equalTo(@13);
        make.height.equalTo(@9);
    }];
    
    [_commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_commentImageView.mas_right).offset(2);
        make.centerY.equalTo(_imageView.mas_centerY);
    }];
    
    [_downloadLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.mas_right).offset(-10);
        make.centerY.equalTo(_imageView.mas_centerY);
    }];
    
    [_downloadImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_downloadLabel.mas_left).offset(-2);
        make.centerY.equalTo(_imageView.mas_centerY);
    }];
    
    [_starView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom);
        make.left.equalTo(_appNameLabel.mas_left);
        make.width.equalTo(@65);
        make.height.equalTo(@23);
    }];
    
}

// 重写Setter方法
- (void)setModel:(AppModel *)model
{
    _model = model;
    [_imageView sd_setImageWithURL:[NSURL URLWithString:_model.iconUrl] placeholderImage:[UIImage imageNamed:@"appproduct_appdefault"]];
    _appNameLabel.text = _model.name;
    _commentLabel.text = _model.ratingOverall;
    _downloadLabel.text = _model.downloads;
    
    [_starView setStartValue:[_model.starOverall floatValue]];
}

@end
