//
//  SettingCell.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/18.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end
