//
//  TableFooterView.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, RefreshStatus)
{
    RefreshStatusNotVisiable, // 不可见
    RefreshStatusLoading,     // 加载中
    RefreshStatusError,       // 加载失败
    RefreshStatusMore,        // 加载更多
    RefreshStatusNotMore,     // 没有更多
};

@interface TableFooterView : UIView
// 表示当前状态
@property (nonatomic, assign) RefreshStatus status;

// 是否能够响应点击
- (BOOL)respondsToTouch;

@end
