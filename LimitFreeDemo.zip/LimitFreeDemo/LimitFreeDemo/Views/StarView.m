//
//  StarView.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/15.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "StarView.h"

@implementation StarView
{
    UIImageView * _backgroundImageView; // 背景图片
    UIImageView * _foregroundImageView; // 前景图片
}

// 重写初始化方法
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self createViews];
    }
    return self;
}

// 在xib或者Storyboard中，某个视图设置了Custom Class之后，在xib或者Storyboard创建出来之后，其中视图将会调用这个初始化方法。
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder]) {
        [self createViews];
    }
    return self;
}



- (void)createViews
{
    // 背景图
    _backgroundImageView = [[UIImageView alloc] init];
    [self addSubview:_backgroundImageView];
    _backgroundImageView.image = [UIImage imageNamed:@"StarsBackground"];
    // 设置内容模式
    _backgroundImageView.contentMode = UIViewContentModeLeft;
    
    [_backgroundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    // 前景图
    _foregroundImageView = [[UIImageView alloc] init];
    [self addSubview:_foregroundImageView];
    _foregroundImageView.image = [UIImage imageNamed:@"StarsForeground"];
    // 设置内容模式
    _foregroundImageView.contentMode = UIViewContentModeLeft;
    // 设置裁剪
    _foregroundImageView.clipsToBounds = YES;
    _foregroundImageView.translatesAutoresizingMaskIntoConstraints = NO;
    
    [_foregroundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
}

// 通过传入的参数确定显示星数[0~5]
- (void)setStartValue:(CGFloat) value
{
    if (value < 0 || value > 5) {
        return;
    }
    // 修改前景图的尺寸
    [_foregroundImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.and.bottom.equalTo(self);
        make.width.equalTo(_backgroundImageView.mas_width).multipliedBy(value / 5.0);
    }];
}

@end
