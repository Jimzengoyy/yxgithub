//
//  CollectionTableModel.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/21.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "CollectionTableModel.h"

@implementation CollectionTableModel

@end
