//
//  AppDetailModel.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/17.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "AppDetailModel.h"

@implementation AppDetailModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"description"]) {
        self.desc = value;
    }
    
}

// 重写photos属性的Setter方法
- (void)setPhotos:(NSArray *)photos
{
    NSMutableArray * photosModels = [NSMutableArray array];
    for (NSDictionary * dict in photos) {
        Photos * photo = [[Photos alloc] init];
        // 通过KVC方式映射
        [photo setValuesForKeysWithDictionary:dict];
        [photosModels addObject:photo];
    }
    _photos = [photosModels copy];
}

@end


@implementation Photos

@end


