//
//  BaseModel.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
