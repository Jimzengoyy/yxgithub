//
//  SubjectModel.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/16.
//  Copyright © 2015年 1000phone. All rights reserved.
//

/**
 *  专题模型
 */
#import <Foundation/Foundation.h>
#import "BaseModel.h"

@interface SubjectModel : BaseModel

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *desc_img;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray *applications;

@property (nonatomic, copy) NSString *date;

@end

