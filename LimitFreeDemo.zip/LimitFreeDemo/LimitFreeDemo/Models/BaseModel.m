//
//  BaseModel.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

// 重写方法
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

- (id)valueForUndefinedKey:(NSString *)key
{
    return nil;
}

@end
