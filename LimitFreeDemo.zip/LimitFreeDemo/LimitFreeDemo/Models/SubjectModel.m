//
//  SubjectModel.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/16.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "SubjectModel.h"
#import "AppModel.h"

@implementation SubjectModel

- (void)setApplications:(NSArray *)applications
{
    // 判断数组是否为空数组
    if (applications.count == 0) {
        _applications = applications;
    }
    else {
        NSMutableArray * appModels = [NSMutableArray array];
        for (NSDictionary * appDict in applications) {
            AppModel * appModel = [[AppModel alloc] init];
            [appModel setValuesForKeysWithDictionary:appDict];
            [appModels addObject:appModel];
        }
        // 对实例变量赋值
        _applications = [appModels copy];
    }
}


@end


