//
//  CollectionTableModel.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/21.
//  Copyright © 2015年 1000phone. All rights reserved.
//

/**
 *  数据库中collection表对应的模型
 */
#import <Foundation/Foundation.h>

@interface CollectionTableModel : NSObject

@property (nonatomic, copy) NSString * appId;
@property (nonatomic, copy) NSString * appName;
@property (nonatomic, copy) NSString * appImage;

@end
