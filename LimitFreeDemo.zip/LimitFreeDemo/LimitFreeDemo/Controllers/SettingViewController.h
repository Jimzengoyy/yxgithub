//
//  SettingViewController.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/18.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface SettingViewController : BaseViewController

@end
