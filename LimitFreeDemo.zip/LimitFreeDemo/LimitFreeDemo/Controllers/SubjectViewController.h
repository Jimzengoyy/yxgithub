//
//  SubjectViewController.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface SubjectViewController : BaseViewController

@end
