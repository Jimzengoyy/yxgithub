//
//  CollectionViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/21.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "CollectionViewController.h"
#import "DatabaseManager.h"
#import "CollectionCell.h"

// 删除按钮开始的标记值
#define DELETE_BUTTON_BEGIN_TAG 100

@interface CollectionViewController ()<UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) UICollectionView * collectionView;
@property (nonatomic, strong) NSMutableArray * dataArray;
@property (nonatomic, assign) BOOL isEditing; // 记录当前是否处于编辑状态

@end

@implementation CollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    [self createUI];
    
    // GCD
    // __weak typeof(*self) * weakSelf = self
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        weakSelf.dataArray = [NSMutableArray arrayWithArray:[[DatabaseManager sharedManager] getAllCollection]];
        // 回到主队列刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            // 重新加载数据
            [weakSelf.collectionView reloadData];
        });
    });
    
    // 自定义导航项
    [self customNavigationItem];
}

// 自定义导航项
- (void)customNavigationItem
{
    // 设置标题
    [self addNavigationItemTitle:@"我的收藏"];
    [self addBarButtonItemWithTarget:self action:@selector(back:) name:@"返回" isLeft:YES];
    [self addBarButtonItemWithTarget:self action:@selector(onEdit:) name:@"编辑" isLeft:NO];
}

- (void)back:(UIButton *) sender
{
    // 返回上一级
    [self.navigationController popViewControllerAnimated:YES];
}

// 编辑按钮点击
- (void)onEdit:(UIButton *) sender
{
    if (self.isEditing) {
        [sender setTitle:@"编辑" forState:UIControlStateNormal];
        self.isEditing = NO;
    }
    else {
        [sender setTitle:@"完成" forState:UIControlStateNormal];
        self.isEditing = YES;
    }
    // 重新刷新UIColletionView，显示或者隐藏删除按钮以及动画
    [self.collectionView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

// 创建视图
- (void)createUI
{
    UICollectionViewFlowLayout * flowLayout = [[UICollectionViewFlowLayout alloc] init];
    self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:flowLayout];
    [self.view addSubview:self.collectionView];
    self.collectionView.backgroundColor = [UIColor whiteColor];
    // 设置数据源和代理
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    
    flowLayout.itemSize = CGSizeMake(80, 80 + 30);
    // 设置间隙
    // 设置行间距
    flowLayout.minimumLineSpacing = 20;
    // 设置单元格间距
    flowLayout.minimumInteritemSpacing = 20;
    // 设置内间距
    flowLayout.sectionInset = UIEdgeInsetsMake(30, 30, 30, 30);
    // 注册单元格
    [self.collectionView registerNib:[UINib nibWithNibName:@"CollectionCell" bundle:nil] forCellWithReuseIdentifier:@"CollectionCell"];
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

// 单元格
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // 复用
    CollectionCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CollectionCell" forIndexPath:indexPath];
    // 取出对应的模型
    CollectionTableModel * model = self.dataArray[indexPath.row];
    cell.appNameLabel.text = model.appName;
    [cell.appImageView sd_setImageWithURL:[NSURL URLWithString:model.appImage] placeholderImage:[UIImage imageNamed:@"appproduct_appdefault"]];
    
    // 判断当前是否处于编辑状态
    if (self.isEditing) {
        cell.deleteButton.hidden = NO;
        // 动画
        cell.transform = CGAffineTransformMakeRotation(-0.05);
        [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionRepeat | UIViewAnimationOptionAutoreverse | UIViewAnimationOptionAllowUserInteraction animations:^{
            cell.transform = CGAffineTransformMakeRotation(0.05);
        } completion:nil];
        
    }
    else {
        cell.deleteButton.hidden = YES;
        // 恢复原状
        cell.transform = CGAffineTransformIdentity;
        [cell.layer removeAllAnimations];
    }
    
    // 添加删除按钮点击事件
    [cell.deleteButton addTarget:self action:@selector(deleteCellClicked:) forControlEvents:UIControlEventTouchDown];
    // 设置删除按钮的tag值
    cell.deleteButton.tag = DELETE_BUTTON_BEGIN_TAG + indexPath.row;
    
    return cell;
}

- (void)deleteCellClicked:(UIButton *) sender
{
    NSLog(@"delete");
    // 获取点击删除按钮对应的单元格位置
    NSInteger selectedIndex = sender.tag - DELETE_BUTTON_BEGIN_TAG;
    // 删除数据
    // 找到对应的模型数据
    CollectionTableModel * model = self.dataArray[selectedIndex];
    // 删除数据库数据
    BOOL isSuccess = [[DatabaseManager sharedManager] deleteColletionTableModel:model];
    if (isSuccess) {
        [self.dataArray removeObjectAtIndex:selectedIndex];
        NSIndexPath * indexPath = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
        [self.collectionView deleteItemsAtIndexPaths:@[indexPath]];
        
        // 重新刷新UICollectionView，重新计算删除按钮的tag值
        // 延迟执行刷新
        // 参数1：延迟执行的时间
        // dispatch_time创建时间，DISPATCH_TIME_NOW当前时间，delta时间间隔
        // 参数2：执行的队列，参数3：执行block
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 0.35*NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [self.collectionView reloadData];
        });
    }
    else {
        [KVNProgress showErrorWithStatus:@"删除收藏失败"];
    }
    
    
    
    

    // 找到按钮对应的单元格视图
/*    CollectionCell * superCell = (CollectionCell *)sender.superview.superview;
    // 找到单元格在UICollectionView中的位置
    NSIndexPath * indexPath = [self.collectionView indexPathForCell:superCell];
    [self.dataArray removeObjectAtIndex:indexPath.row];
    [self.collectionView deleteItemsAtIndexPaths:@[indexPath]];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.collectionView reloadData];
    });
*/
}

@end
