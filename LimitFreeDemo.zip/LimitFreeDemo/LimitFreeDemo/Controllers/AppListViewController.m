//
//  AppListViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "AppListViewController.h"
#import "LimitFreeNetworkingManager.h"
#import "AppModel.h"
#import "TableFooterView.h"
#import "AppCell.h"
#import "SearchViewController.h"
#import "CategoryViewController.h"
#import "AppDetailViewController.h"
#import "SettingViewController.h"

@interface AppListViewController ()<UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>
{
    UITableView * _tableView;
    NSMutableArray * _dataArray;
    UIRefreshControl * _refreshControl; // UITableView的表头下拉刷新
    NSInteger _currentPage; // 记录当前请求的page
    TableFooterView * _tableFooterView; // 上拉加载更多视图
}

@property (nonatomic, strong) LimitFreeNetworkingManager * manager; // 网络请求

@end

@implementation AppListViewController

// 通过懒加载方式创建对象，重写属性的Getter方法
// 如果重写了Getter方法，只能通过属性访问，不能通过实例变量访问
- (LimitFreeNetworkingManager *)manager
{
    if (!_manager) {
        _manager = [LimitFreeNetworkingManager manager];
    }
    return _manager;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createTableView];
    [self createSearchBar];
    [self customNavigationItem];
    
    _currentPage = 1;
    [self firstLoad];
}

// 第一次加载
- (void)firstLoad
{
    // 让刷新控件启动动画，并且请求数据
    [_refreshControl beginRefreshing];
    [self headerRefresh:_refreshControl];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)createTableView
{
    _tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:_tableView];
    // 设置UITableView的数据源和代理
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    _tableView.rowHeight = 120;
    
    // 注册单元格，通过NIB文件注册单元格
    // 参数1：Nib对象
    // 参数2：复用的标识
    [_tableView registerNib:[UINib nibWithNibName:@"AppCell" bundle:nil] forCellReuseIdentifier:@"AppCell"];
    
    // 下拉刷新控件
    _refreshControl = [[UIRefreshControl alloc] init];
    [_tableView addSubview:_refreshControl];
    _refreshControl.tintColor = [UIColor orangeColor];
    [_refreshControl addTarget:self action:@selector(headerRefresh:) forControlEvents:UIControlEventValueChanged];
    
    // 创建上拉加载更多视图
    _tableFooterView = [[TableFooterView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    _tableView.tableFooterView = _tableFooterView;
    // 添加手势
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(requestMore:)];
    [_tableFooterView addGestureRecognizer:tapGesture];
}

// 下拉刷新
- (void)headerRefresh:(UIRefreshControl *) sender
{
    _currentPage = 1;
    // 请求数据
    [self requestDataOnPage:_currentPage search:self.searchKeyword categoryID:self.cateID];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 复用单元格，通过注册方式关联的单元格通过该方法进行单元格的复用时，如果没有找到可以复用的单元格内部将自动创建单元格
    AppCell * cell = [tableView dequeueReusableCellWithIdentifier:@"AppCell" forIndexPath:indexPath];
    
    // 读取对应的AppModel
    AppModel * model = _dataArray[indexPath.row];
    
    // 关联单元格和模型
    cell.model = model;
    
    return cell;
}

#pragma mark - UITableViewDelegate
// 单元格点击回调
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppModel * model = _dataArray[indexPath.row];
    // 创建应用详情视图控制器
    AppDetailViewController * appDetailVC = [[AppDetailViewController alloc] init];
    appDetailVC.applicationID = model.applicationId;
    [self.navigationController pushViewController:appDetailVC animated:YES];
}


#pragma mark - 数据相关

- (void)requestDataOnPage:(NSInteger)page search:(NSString *) search categoryID:(NSString *) cateid
{
    NSString * url = [NSString stringWithFormat:self.requestURL, page, search ? search : @""];
    // 判断分类是否设置
    if (cateid.length != 0) {
        url = [url stringByAppendingString:[NSString stringWithFormat:@"&cate_id=%@", cateid]];
    }
    
    // 对URL进行编码
    url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [self.manager GET:url parameters:nil success:^(NSURLResponse *response, NSData *data) {
        NSDictionary * responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"%@", responseDict);
        // 读取所有的Applications
        NSArray * applications = responseDict[@"applications"];
        // 判断数据源是否为空
        if (!_dataArray) {
            _dataArray = [NSMutableArray array];
        }
        // 当请求的页数为1时，将数据清空
        if (_currentPage == 1) {
            [_dataArray removeAllObjects];
        }
        
        for (NSDictionary * appDict in applications) {
            // 将字典转换为模型
            AppModel * model = [[AppModel alloc] init];
            [model setValuesForKeysWithDictionary:appDict];
            [_dataArray addObject:model];
        }
        // 刷新UITableView
        dispatch_sync(dispatch_get_main_queue(), ^{
            [_refreshControl endRefreshing];
            [_tableView reloadData];
            // 更新TableFooterView的状态
            _tableFooterView.status = RefreshStatusMore;
        });
        
    } failure:^(NSURLResponse *response, NSError *error) {
        NSLog(@"%@", error.localizedDescription);
        if (_currentPage == 1) {
            [_refreshControl endRefreshing];
        }
        else {
            _currentPage--;
            _tableFooterView.status = RefreshStatusError;
        }
    }];
}

// 请求更多的数据
- (void)requestMore:(UITapGestureRecognizer *) sender
{
    if ([_tableFooterView respondsToTouch]) {
        _tableFooterView.status = RefreshStatusLoading;
        [self requestDataOnPage:++_currentPage search:self.searchKeyword categoryID:self.cateID];
    }
}

#pragma mark - UIScrollViewDelegate
// 滚动视图拖拽结束
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView.contentOffset.y + scrollView.frame.size.height > scrollView.contentSize.height) {
        [self requestMore:nil];
    }
}

#pragma mark - 搜索功能
- (void)createSearchBar
{
    UISearchBar * searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    // 将UISearchBar添加到UITableView的表头
    _tableView.tableHeaderView = searchBar;
    searchBar.delegate = self;
    searchBar.placeholder = @"来搜我呀";
    // 显示取消按钮
    searchBar.showsCancelButton = YES;
}

#pragma mark - UISearchBarDelegate
// 点击Cancel按钮回调
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    // 清空输入框内容、收起键盘
    searchBar.text = nil;
    [searchBar resignFirstResponder];
}

// 点击键盘上搜索时回调
// 跳转到搜索界面显示搜索结果
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    NSLog(@"%s", __func__);
    SearchViewController * searchVC = [[SearchViewController alloc] init];
    searchVC.requestURL = self.requestURL;
    searchVC.searchKeyword = searchBar.text;
    searchVC.cateID = self.cateID;
    
    [self.navigationController pushViewController:searchVC animated:YES];
}

// 定制导航项
- (void)customNavigationItem
{
    // 设置导航按钮
    [self addBarButtonItemWithTarget:self action:@selector(onLeftClicked:) name:@"分类" isLeft:YES];
    [self addBarButtonItemWithTarget:self action:@selector(onRightClicked:) name:@"设置" isLeft:NO];
}

// 导航项上左侧按钮点击
- (void)onLeftClicked:(UIButton *) sender
{
    NSArray * types = @[kLimitType, kReduceType, kFreeType, kSubjectType, kHotType];
    CategoryViewController * categoryVC = [[CategoryViewController alloc] init];
    // 当push时隐藏TabBar
    categoryVC.hidesBottomBarWhenPushed = YES;
    categoryVC.type = types[self.tabBarController.selectedIndex];
    categoryVC.block = ^(NSString * cateID) {
        self.cateID = cateID;
        _currentPage = 1;
        [self firstLoad];
    };
    
    [self.navigationController pushViewController:categoryVC animated:YES];
}

// 导航项上右侧按钮点击
- (void)onRightClicked:(UIButton *) sender
{
    SettingViewController * settingVC = [[SettingViewController alloc] init];
    settingVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:settingVC animated:YES];
}


@end
