//
//  CategoryViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/15.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "CategoryViewController.h"
#import "LimitFreeNetworkingManager.h"
#import "CategoryModel.h"
#import "UIImageView+WebCache.h"

@interface CategoryViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray * dataArray;
@property (nonatomic, strong) LimitFreeNetworkingManager * netManager;
@property (nonatomic, strong) UITableView * tableView;
// 大分类对应的中文名称
@property (nonatomic, strong) NSString * typeName;
// 大分类在分类列表数据对应key
@property (nonatomic, strong) NSString * categoryKey;

@end

@implementation CategoryViewController

// 懒加载
- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (LimitFreeNetworkingManager *)netManager
{
    if (!_netManager) {
        _netManager = [LimitFreeNetworkingManager manager];
    }
    return _netManager;
}

// 重写type的Setter方法
- (void)setType:(NSString *)type
{
    _type = type;
    NSArray * types = @[kLimitType, kReduceType, kFreeType, kHotType];
    NSArray * typeNames = @[@"限免", @"降价", @"免费", @"热榜"];
    NSArray * cateKeys = @[@"limited", @"down", @"free", @"up"];
    NSDictionary * typeDict = [NSDictionary dictionaryWithObjects:typeNames forKeys:types];
    NSDictionary * cateDict = [NSDictionary dictionaryWithObjects:cateKeys forKeys:types];
    self.typeName = typeDict[_type];
    self.categoryKey = cateDict[_type];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self addNavigationItemTitle:self.typeName];
    self.navigationItem.leftBarButtonItem = nil;
    self.navigationItem.rightBarButtonItem = nil;
    [self addBarButtonItemWithTarget:self action:@selector(back:) name:@"返回" isLeft:YES];
    UIButton * leftButton = (UIButton *)self.navigationItem.leftBarButtonItem.customView;
    [leftButton setBackgroundImage:[UIImage imageNamed:@"buttonbar_back"] forState:UIControlStateNormal];
    
    // 创建视图
    [self createTableView];
    // 请求数据
    [self requestCategoryData];
}

- (void)back:(UIButton *) sender
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 请求所有的分类数据
- (void)requestCategoryData
{
    [self.netManager GET:kCateUrl parameters:nil success:^(NSURLResponse *response, NSData *data) {
        NSArray * responseArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        // 遍历数组
        for (NSDictionary * categoryDict in responseArray) {
            CategoryModel * model = [[CategoryModel alloc] init];
            // 通过KVC赋值
            [model setValuesForKeysWithDictionary:categoryDict];
            [self.dataArray addObject:model];
        }
        
        // 回到主队列中刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
        
    } failure:^(NSURLResponse *response, NSError *error) {
        
    }];
}

// 创建UI
- (void)createTableView
{
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 100;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 复用
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"CELL"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"CELL"];
    }
    // 读取对应的模型
    CategoryModel * model = self.dataArray[indexPath.row];
    // 设置图片
    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:model.picUrl] placeholderImage:[UIImage imageNamed:@"category_All.jpg"]];
    // 设置主标题
    cell.textLabel.text = model.categoryCname;
    // 设置副标题
    NSString * subTitle = [NSString stringWithFormat:@"共%@款应用，其中%@%@款", model.categoryCount, self.typeName, [model valueForKey:self.categoryKey]];
    cell.detailTextLabel.text = subTitle;
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoryModel * model = self.dataArray[indexPath.row];
    
    // 判断当前block是否存在
    if (self.block) {
        if ([model.categoryId isEqualToString:@"0"]) {
            self.block(nil);
        }
        else {
            self.block(model.categoryId);
        }
    }
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
