//
//  AppDetailViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/17.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "AppDetailViewController.h"
#import "AppDetailModel.h"
#import "LimitFreeNetworkingManager.h"
#import "UIImageView+WebCache.h"
#import <CoreLocation/CoreLocation.h>
#import "AppModel.h"
#import "BigPictureViewController.h"
// 导入友盟分享的头文件
#import "UMSocial.h"
// 导入数据库管理头文件
#import "DatabaseManager.h"

// APP的图片展示开始的tag值
#define APP_PICTURE_BEGIN_TAG 10
// 附近的人使用的APP图片的tag值
#define NEAR_APP_BEGIN_TAG 100


@interface AppDetailViewController ()<CLLocationManagerDelegate>
#pragma mark - UI部分
@property (weak, nonatomic) IBOutlet UIImageView *appImageView;
@property (weak, nonatomic) IBOutlet UILabel *appNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *categoryLabel;
- (IBAction)shareClicked:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *favouriteButton;
- (IBAction)favouriteClicked:(UIButton *)sender;
- (IBAction)downloadClicked:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIScrollView *appPictureScrollView;
@property (weak, nonatomic) IBOutlet UITextView *appDescTextView;
@property (weak, nonatomic) IBOutlet UIScrollView *recommendAppScrollView;

#pragma mark - 数据部分
@property (nonatomic, strong) LimitFreeNetworkingManager * manager;
@property (nonatomic, strong) AppDetailModel * detailModel;

#pragma mark - 定位部分
// 定位管理对象
@property (nonatomic, strong) CLLocationManager * locationManager;
@property (nonatomic, strong) CLLocation * location;
@property (nonatomic, strong) NSArray * nearAppArray;

@end

@implementation AppDetailViewController

// 懒加载
- (AppDetailModel *)detailModel
{
    if (!_detailModel) {
        _detailModel = [[AppDetailModel alloc] init];
    }
    return _detailModel;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self customNavigationItem];
    
    [self requestDetailModel];
    [self createLocationManager];
    
    // 判断当前应用是否已收藏
    BOOL isCollection = [[DatabaseManager sharedManager] isExistsWithAppId:self.applicationID];
    // 修改收藏按钮的状态
    self.favouriteButton.enabled = !isCollection;
}

// 定制导航项
- (void)customNavigationItem
{
    [self addNavigationItemTitle:@"应用详情"];
    [self addBarButtonItemWithTarget:self action:@selector(back:) name:@"返回" isLeft:YES];
    UIButton * leftButton = self.navigationItem.leftBarButtonItem.customView;
    [leftButton setBackgroundImage:[UIImage imageNamed:@"buttonbar_back"] forState:UIControlStateNormal];
}

// 返回上一级
- (void)back:(UIButton *) sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 请求数据
- (void)requestDetailModel
{
    self.manager = [LimitFreeNetworkingManager manager];
    NSString * detailURL = [NSString stringWithFormat:kDetailUrl, self.applicationID];
    
    // 将self变成weak指针
    __weak typeof(*self) * weakSelf = self;
    [self.manager GET:detailURL parameters:nil success:^(NSURLResponse *response, NSData *data) {
        NSDictionary * responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        [weakSelf.detailModel setValuesForKeysWithDictionary:responseDict];
        // 回到主队列中更新视图
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf updateUI];
        });
        
    } failure:^(NSURLResponse *response, NSError *error) {
        NSLog(@"%@", error.localizedDescription);
    }];
}

// 请求附近在使用的App信息
- (void)requestNearAppData
{
    // 拼接请求地址
    NSString * nearAppURL = [NSString stringWithFormat:kNearAppUrl, self.location.coordinate.longitude, self.location.coordinate.latitude];
    // 请求数据
    [self.manager GET:nearAppURL parameters:nil success:^(NSURLResponse *response, NSData *data) {
        NSDictionary * responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSArray * applications = responseDict[@"applications"];
        NSMutableArray * appModels = [NSMutableArray array];
        for (NSDictionary * dict in applications) {
            AppModel * model = [[AppModel alloc] init];
            [model setValuesForKeysWithDictionary:dict];
            [appModels addObject:model];
        }
        self.nearAppArray = [appModels copy];
        
        // 回到主线程中刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            [self updateNearApp];
        });
        
    } failure:^(NSURLResponse *response, NSError *error) {
        NSLog(@"%@", error.localizedDescription);
    }];
}

// 更新附近的App数据
- (void)updateNearApp
{
    // 获取图片的尺寸
    CGFloat imageHeight = CGRectGetHeight(self.recommendAppScrollView.frame);
    for (int index = 0; index < self.nearAppArray.count; index++) {
        // 取出对应的模型数据
        AppModel * model = self.nearAppArray[index];
        
        UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(index*imageHeight, 0, imageHeight, imageHeight)];
        [self.recommendAppScrollView addSubview:imageView];
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.iconUrl] placeholderImage:[UIImage imageNamed:@"appproduct_appdefault"]];
        // 添加手势识别器
        UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onNearAppTap:)];
        [imageView addGestureRecognizer:tapGesture];
        // 设置tag值
        imageView.tag = NEAR_APP_BEGIN_TAG + index;
        imageView.userInteractionEnabled = YES;
    }
    // 设置contentSize
    self.recommendAppScrollView.contentSize = CGSizeMake(imageHeight*self.nearAppArray.count, imageHeight);
}

// 手势识别器响应方法
- (void)onNearAppTap:(UITapGestureRecognizer *) sender
{
    NSInteger selectedIndex = sender.view.tag - NEAR_APP_BEGIN_TAG;
    // 取出对应的模型数据
    AppModel * model = self.nearAppArray[selectedIndex];
    AppDetailViewController * detailVC = [[AppDetailViewController alloc] init];
    detailVC.applicationID = model.applicationId;
    // 通过push方式显示
    [self.navigationController pushViewController:detailVC animated:YES];
}

// 更新UI
- (void)updateUI
{
    [self.appImageView sd_setImageWithURL:[NSURL URLWithString:self.detailModel.iconUrl] placeholderImage:[UIImage imageNamed:@"appproduct_appdefault"]];
    self.appNameLabel.text = self.detailModel.name;
    self.priceLabel.text = [NSString stringWithFormat:@"原价:￥%@ 限免中 文件大小:%@MB", self.detailModel.lastPrice, _detailModel.fileSize];
    self.categoryLabel.text = [NSString stringWithFormat:@"类型:%@ 评分:%@", self.detailModel.categoryName, self.detailModel.starOverall];
    self.appDescTextView.text = self.detailModel.desc;
    // 显示滚动图片
    // 在AutoLayout中如果界面还没有显示出来，获取的frame只是在xib或者Storyboard中对应的尺寸，不是在对应的设备上的尺寸。要在一个AutoLayout布局的视图中添加子视图时，有两种方式：要添加的视图还是使用约束；等到UI加载完成时才使用
    NSLog(@"%@", NSStringFromCGRect(self.appPictureScrollView.frame));
    // 遍历图片数组
    CGFloat imageHeight = CGRectGetHeight(self.appPictureScrollView.frame);
    
    for (int index = 0; index < self.detailModel.photos.count; index++) {
        // 取出对应的模型数据
        Photos * photo = self.detailModel.photos[index];
        UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(index*imageHeight, 0, imageHeight, imageHeight)];
        // 将图片视图添加到UIScrollView中
        [self.appPictureScrollView addSubview:imageView];
        [imageView sd_setImageWithURL:[NSURL URLWithString:photo.smallUrl] placeholderImage:[UIImage imageNamed:@"appproduct_appdefault"]];
        // 开启用户交互
        imageView.userInteractionEnabled = YES;
        // 添加tap手势识别器
        UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onAppPictureTap:)];
        [imageView addGestureRecognizer:tapGesture];
        // 设置标记值
        imageView.tag = APP_PICTURE_BEGIN_TAG + index;
    }
    // 设置内容的尺寸
    self.appPictureScrollView.contentSize = CGSizeMake(imageHeight*self.detailModel.photos.count, imageHeight);
    
}

// APP图片点击的手势响应方法
- (void)onAppPictureTap:(UITapGestureRecognizer *) sender
{
    // 获取点击的图片
    UIView * tapView = sender.view;
    // 获取点击的index
    NSInteger selectedIndex = tapView.tag - APP_PICTURE_BEGIN_TAG;
    // 创建大图显示视图控制器
    BigPictureViewController * bpvc = [[BigPictureViewController alloc] init];
    bpvc.photos = self.detailModel.photos;
    bpvc.selectedIndex = selectedIndex;
    bpvc.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
//    UIModalTransitionStyleCoverVertical = 0,
//    UIModalTransitionStyleFlipHorizontal __TVOS_PROHIBITED,
//    UIModalTransitionStyleCrossDissolve,
//    UIModalTransitionStylePartialCurl
    [self presentViewController:bpvc animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)shareClicked:(UIButton *)sender {
    
    // 分享的文字
    NSString * shareText = [NSString stringWithFormat:@"%@ %@ %@", self.detailModel.name, self.detailModel.desc, self.detailModel.itunesUrl];
    // 分享的图片
    UIImage * shareImage = self.appImageView.image;
    
    // 友盟分享
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:nil
                                      shareText:shareText
                                     shareImage:shareImage
                                shareToSnsNames:nil
                                       delegate:nil];
}
- (IBAction)favouriteClicked:(UIButton *)sender {
    // 判断当前是否已加载
    if (!self.detailModel) {
        [KVNProgress showErrorWithStatus:@"应用详情暂未加载"];
        return;
    }
    
    CollectionTableModel * model = [[CollectionTableModel alloc] init];
    model.appId = self.detailModel.applicationId;
    model.appName = self.detailModel.name;
    model.appImage = self.detailModel.iconUrl;
    
    // 将数据插入数据库中
    BOOL isSuccess = [[DatabaseManager sharedManager] insertCollectionTableModel:model];
    if (isSuccess) {
        self.favouriteButton.enabled = NO;
        [KVNProgress showSuccessWithStatus:@"收藏成功"];
    }
    else {
        [KVNProgress showErrorWithStatus:@"收藏失败"];
    }
}

- (IBAction)downloadClicked:(UIButton *)sender {
    // 打开URL地址
    // 打开网址
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.baidu.com"]];
    // 拨打电话
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://18981988677"]];
    // 发邮件
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"mailto://352135591@qq.com"]];
    // 发短信
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"sms://10001"]];
    // 下载应用需要跳转到App Store中下载
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.detailModel.itunesUrl]];
}

#pragma mark - 定位
- (void)createLocationManager
{
    self.locationManager = [[CLLocationManager alloc] init];
    // 设置代理
    self.locationManager.delegate = self;
    // 设置定位更新频率
    self.locationManager.distanceFilter = 100;
    // 设置定位的精度
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    // 请求用户权限
    // 判断当前应用是否已授权
    CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
    if (status == kCLAuthorizationStatusNotDetermined) {
        [self.locationManager requestAlwaysAuthorization];
    }
    // 在plist文件中添加描述信息
    // 开始定位
    [self.locationManager startUpdatingLocation];
}

#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    if (locations.count != 0) {
        self.location = [locations lastObject];
        // 根据经纬度请求数据
        [self requestNearAppData];
        
        // 停止定位服务
        [self.locationManager stopUpdatingLocation];
    }
}

@end
