//
//  MySettingViewController.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/22.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MySettingViewController : UITableViewController

@end
