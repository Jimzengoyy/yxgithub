//
//  TabBarViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "TabBarViewController.h"
#import "LimitViewController.h"
#import "ReduceViewController.h"
#import "FreeViewController.h"
#import "SubjectViewController.h"
#import "HotViewController.h"
#import "CategoryViewController.h"

@interface TabBarViewController ()

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self customTabBar];
    [self createViewControllers];
    [self customNavigationBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 创建视图控制器
- (void)createViewControllers
{
    // 读取plist文件
    NSString * plistPath = [[NSBundle mainBundle] pathForResource:@"Controllers" ofType:@"plist"];
    NSArray * plistArray = [NSArray arrayWithContentsOfFile:plistPath];
    
    // 创建存放视图控制器的数组
    NSMutableArray * viewControllers = [NSMutableArray array];
    
    for (NSDictionary * dict in plistArray) {
        NSString * title = dict[@"title"];
        NSString * iconName = dict[@"iconName"];
        NSString * className = dict[@"className"];
        // 创建视图控制器
        // 根据类名获取对应的Class，Class是一个结构体指针，指的是类对应的Class的对象，存储的是这个类对应的isa指针，类名、方法列表
        Class class = NSClassFromString(className);
        // 通过Class对象创建该Class对应类的对象
        AppListViewController * appListVC = [[class alloc] init];
        
        // 将视图控制器放入导航控制器中
        UINavigationController * navi = [[UINavigationController alloc] initWithRootViewController:appListVC];
        
        // 设置导航项
        [appListVC addNavigationItemTitle:title];
        
        
        // 设置TabBarItem
        UIImage * normalImage = [[UIImage imageNamed:iconName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        UIImage * selectedImage = [[UIImage imageNamed:[NSString stringWithFormat:@"%@_press", iconName]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        UITabBarItem * tabBarItem = [[UITabBarItem alloc] initWithTitle:title image:normalImage selectedImage:selectedImage];
        
        navi.tabBarItem = tabBarItem;
        
        // 添加到数组中
        [viewControllers addObject:navi];
    }
    
    // 设置UITabBarController
    self.viewControllers = viewControllers;
}

// 自定义UITabBar
- (void)customTabBar
{
    UITabBar * tabBar = self.tabBar;
    // 设置背景图片
    [tabBar setBackgroundImage:[UIImage imageNamed:@"tabbar_bg"]];
}

// 自定义UINavigationBar
- (void)customNavigationBar
{
    // 获取所有的视图控制器
    NSArray * viewControllers = self.viewControllers;
    
    for (UINavigationController * navi in viewControllers) {
        // 获取UINavigationBar
        UINavigationBar * navigationBar = navi.navigationBar;
        // 设置背景图片
        [navigationBar setBackgroundImage:[UIImage imageNamed:@"navigationbar"] forBarMetrics:UIBarMetricsDefault];
    }
}

@end
