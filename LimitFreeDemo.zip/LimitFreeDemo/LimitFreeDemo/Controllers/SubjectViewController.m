//
//  SubjectViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "SubjectViewController.h"
#import "LimitFreeNetworkingManager.h"
#import "SubjectModel.h"
#import "SubjectCell.h"

@interface SubjectViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) LimitFreeNetworkingManager * manager; // 网络请求
@property (nonatomic, strong) NSMutableArray * dataArray;
@property (nonatomic, strong) UITableView * tableView;
@property (nonatomic, assign) NSInteger currentPage; // 当前页数


@end

@implementation SubjectViewController

- (LimitFreeNetworkingManager *)manager
{
    if (!_manager) {
        _manager = [LimitFreeNetworkingManager manager];
    }
    return _manager;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.tableView];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.rowHeight = 330;
    
    // 注册单元格
    [self.tableView registerNib:[UINib nibWithNibName:@"SubjectCell" bundle:nil] forCellReuseIdentifier:@"SubjectCell"];
    
    _currentPage = 1;
    
    [self requestDataWithPage:1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - 数据相关
- (void)requestDataWithPage:(NSInteger)page
{
    NSString * requestURL = [NSString stringWithFormat:kSubjectUrl, page];
    [self.manager GET:requestURL parameters:nil success:^(NSURLResponse *response, NSData *data) {
        NSArray * responseArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        // 将数组转换为模型
        for (NSDictionary * subjectDict in responseArray) {
            SubjectModel * model = [[SubjectModel alloc] init];
            [model setValuesForKeysWithDictionary:subjectDict];
            NSLog(@"%@", model);
            [self.dataArray addObject:model];
        }
        // 回到主队列中刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
        
    } failure:^(NSURLResponse *response, NSError *error) {
        
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SubjectCell * cell = [tableView dequeueReusableCellWithIdentifier:@"SubjectCell" forIndexPath:indexPath];
    SubjectModel * model = self.dataArray[indexPath.row];
    cell.model = model;
    
    return cell;
}


@end
