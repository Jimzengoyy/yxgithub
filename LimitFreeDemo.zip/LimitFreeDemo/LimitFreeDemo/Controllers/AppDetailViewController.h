//
//  AppDetailViewController.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/17.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface AppDetailViewController : BaseViewController

// 应用程序ID
@property (nonatomic, copy) NSString * applicationID;


@end
