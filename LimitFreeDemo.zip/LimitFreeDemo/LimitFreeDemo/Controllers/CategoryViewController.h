//
//  CategoryViewController.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/15.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

// 定义传值的block
typedef void(^CategoryBlock)(NSString * cateID);

@interface CategoryViewController : BaseViewController

// limit、free、reduce
@property (nonatomic, copy) NSString * type;

@property (nonatomic, copy) CategoryBlock block;

@end
