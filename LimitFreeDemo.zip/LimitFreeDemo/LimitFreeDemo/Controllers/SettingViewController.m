//
//  SettingViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/18.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "SettingViewController.h"
#import "SettingCell.h"
#import "CollectionViewController.h"
#import "MySettingViewController.h"

@interface SettingViewController ()<UICollectionViewDataSource, UICollectionViewDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) NSArray * namesArray; // 存储设置的名称
@property (nonatomic, strong) NSArray * picsArray; // 存储设置的图片名称

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self customNavigationItem];
    // 注册单元格
    [self.collectionView registerNib:[UINib nibWithNibName:@"SettingCell" bundle:nil] forCellWithReuseIdentifier:@"SettingCell"];
    // 设置单元格的大小
    UICollectionViewFlowLayout * flowLayout = (UICollectionViewFlowLayout *)self.collectionView.collectionViewLayout;
    flowLayout.itemSize = CGSizeMake(57, 57 + 30);
    // 设置间隙
    // 设置行间距
    flowLayout.minimumLineSpacing = 20;
    // 设置单元格间距
    flowLayout.minimumInteritemSpacing = 40;
    // 设置内间距
    flowLayout.sectionInset = UIEdgeInsetsMake(30, 30, 30, 30);
    
    // 设置数据源和代理
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    
    // 赋值
    self.namesArray = @[@"我的设置", @"我的关注", @"我的账号", @"我的收藏", @"我的下载", @"我的评论", @"我的帮助", @"蚕豆应用"];
    self.picsArray = @[@"setting", @"favorite", @"user", @"collect", @"download", @"comment", @"help", @"candou"];
    
    // 刷新UICollectionView
    [self.collectionView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 定制导航项
- (void)customNavigationItem
{
    [self addNavigationItemTitle:@"设置"];
    [self addBarButtonItemWithTarget:self action:@selector(back:) name:@"返回" isLeft:YES];
    UIButton * leftButton = self.navigationItem.leftBarButtonItem.customView;
    [leftButton setBackgroundImage:[UIImage imageNamed:@"buttonbar_back"] forState:UIControlStateNormal];
}

- (void)back:(UIButton *) sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.namesArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // 复用
    SettingCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SettingCell" forIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"account_%@", self.picsArray[indexPath.row]]];
    cell.nameLabel.text = self.namesArray[indexPath.row];
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 3) {
        CollectionViewController * collectionVC = [[CollectionViewController alloc] init];
        [self.navigationController pushViewController:collectionVC animated:YES];
    }
    else if (indexPath.row == 0) {
        // 创建UIStoryboard对象
        UIStoryboard * sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        // 实例化视图控制器
        MySettingViewController * mySettingVC = [sb instantiateViewControllerWithIdentifier:@"MySettingViewController"];
        // push
        [self.navigationController pushViewController:mySettingVC animated:YES];
    }
}


@end
