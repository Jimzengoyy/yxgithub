//
//  AppListViewController.h
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface AppListViewController : BaseViewController

@property (nonatomic, copy) NSString * requestURL;
// 搜索关键字
@property (nonatomic, copy) NSString * searchKeyword;
// 分类ID
@property (nonatomic, copy) NSString * cateID;

@end
