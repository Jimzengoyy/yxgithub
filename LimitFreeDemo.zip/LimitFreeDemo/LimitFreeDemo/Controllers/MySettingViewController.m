//
//  MySettingViewController.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/22.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "MySettingViewController.h"
#import "SDImageCache.h"

@interface MySettingViewController ()

@end

@implementation MySettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 清除缓存
- (void)clearWebCache
{
    // 缓存的文件个数
    NSUInteger diskCount = [[SDImageCache sharedImageCache] getDiskCount];
    // 获取缓存的大小
    NSUInteger cacheSize = [[SDImageCache sharedImageCache] getSize];
    
    NSString * msg = [NSString stringWithFormat:@"缓存文件数量：%lu，缓存文件大小：%.2fM", diskCount, (cacheSize / 1024.0) / 1024.0 ];
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle:@"清除缓存" message:msg preferredStyle:UIAlertControllerStyleActionSheet];
    // 添加Action
    UIAlertAction * cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
        [alertController dismissViewControllerAnimated:YES completion:nil];
    }];
    [alertController addAction:cancel];
    
    // 清除Action
    UIAlertAction * clearAction = [UIAlertAction actionWithTitle:@"清除缓存" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * action) {
        [[SDImageCache sharedImageCache] clearMemory];
        [[SDImageCache sharedImageCache] clearDisk];
    }];
    [alertController addAction:clearAction];
    
    // 显示AlertController
    [self presentViewController:alertController animated:YES completion:nil];
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 清除缓存
    if (indexPath.section == 0 && indexPath.row == 2) {
        [self clearWebCache];
    }
}

@end
