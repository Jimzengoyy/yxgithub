//
//  LimitFreeNetworkingManager.m
//  LimitFreeDemo
//
//  Created by Chaosky on 15/12/14.
//  Copyright © 2015年 1000phone. All rights reserved.
//

#import "LimitFreeNetworkingManager.h"

@implementation LimitFreeNetworkingManager
{
    NSURLSession * _urlSession;
}

+ (instancetype)manager
{
    LimitFreeNetworkingManager * manager = [[LimitFreeNetworkingManager alloc] init];
    return manager;
}

- (instancetype)init
{
    if (self = [super init]) {
        // 创建请求会话，使用默认的配置
        _urlSession = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    }
    return self;
}

// GET请求数据
- (void)GET:(NSString *) url parameters:(NSDictionary *)parameters
    success:(RequestSuccess)success
    failure:(RequestFailure)failure
{
    
    // 拼接请求地址
    // http://www.baidu.com?num=122&dasd=xxx
    NSMutableString * mutableString = [NSMutableString stringWithString:url];
    if (parameters) {
        // 遍历字典
        NSMutableArray * paramsArray = [NSMutableArray array];
        for (NSString * key in parameters.allKeys) {
            NSString * param = [NSString stringWithFormat:@"%@=%@", key, parameters[key]];
            [paramsArray addObject:param];
        }
        // 将数组转换为字符串
        NSString * paramsString = [paramsArray componentsJoinedByString:@"&"];
        [mutableString appendFormat:@"?%@", paramsString];
    }
    
    // 创建请求对象
    NSURLRequest * request = [NSURLRequest requestWithURL:[NSURL URLWithString:mutableString]];
    
    // 通过NSURLSession请求数据
    NSURLSessionDataTask * task = [_urlSession dataTaskWithRequest:request completionHandler:^(NSData * data, NSURLResponse * response, NSError * error) {
        // 判断是否请求成功
        if (!error) {
            if (success) {
                success(response, data);
            }
        }
        else {
            if (failure) {
                failure(response, error);
            }
        }
    }];
    
    // 启动任务
    [task resume];
    
}

@end
